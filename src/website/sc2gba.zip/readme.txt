SC2 GBA MELEE v0.01
by daveb
19/8/2004
http://redirect.to/daveb

History
-------------
This is the first version of SC2 Melee for GBA.  Its more a proof of concept to see what if it be done.
At the moment this contains melee combat between ships - the pkunk fury and the urquan dreadnaught.


Controls
-----------
Left/Right - Rotate ship left/right
Up - Thrust
A Button - Fire main ship weapon
B Button - Activate Ship secondary weapon

How to play
-----------------
For those that dont know, heres briefly how to play
Choose from the ships available (at the moment there are only two)
Try to destory the opponent.
At the bottom of the screen is your remaining crew (essential energy) in green, and
battery in red.  You need battery to fire and for your secondary weapon, but not to thrust.
The two ships available are:
pkunk fury - small & fast, fires in 3 directions at once.  Secondary weapon may restore crew.  
This ship has been know to be reencarnated.
urquan dreadnaught - slow & bulky, fire a laser cannon.  Secondary weapon launches small fighters
to attack opponent.

Status
------------
There are more features missing than present at the moment.  This is a brief list of whats missing, 
all of which I hope to add eventually.
-all the other ships
-sound
-abiltity to pick teams
-better ai - its pretty bad at the mo
-better collision detection
-asteroid colours
-2 player mode
-performance enhancements
-battery backup
-etc

Tested using VisualBoyAdvance and on hardware using a ezf-a kit.
It does run a little slow on hardware although I hope to improve that.

Star Control 2
--------------
This was a great game back in the day, and is still an excellent 2 player game.  
A fair few lunch times at school were spent playing this, especially against Pete and Hugh.
This also contained a cool story mode in which you explored the galaxies resotring peace,
although I must confess I never managed to finish this.  Perhaps one day...
If you havent played this you should.  A few years back the authors made the source code
for the 3do version available and a group of dedicated people are porting this to your system.


thanks
------------
http://www.emuhq.com/vboy/ - visual boy advance for the utilities to test and create
http://www.gbadev.org - a great community that helped me get going
http://www.gbajunkie.co.uk - great gba programming tutorials
http://www.thepernproject.com/ - more great tutorials
http://www.classicgaming.com/starcontrol/ - the star control site - a great reference
http://sc2.sourceforge.net/ - the code for sc2 made available.  although I didnt use anything directly this was a great reference
thanks to you for checking this out...



